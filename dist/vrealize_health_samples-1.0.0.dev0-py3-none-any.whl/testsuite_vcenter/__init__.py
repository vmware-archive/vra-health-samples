from testsuite_vcenter.vcenter import register
