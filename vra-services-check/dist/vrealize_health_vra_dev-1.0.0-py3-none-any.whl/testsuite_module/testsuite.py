# Copyright © 2017-2018 VMware, Inc. All Rights Reserved.
#
################################################################################################
#
# Test Implementation
#
################################################################################################
#from testsuitebase.testsuitebase import test_parameter, test_suite, TestSuiteBase, test, test_name, test_description, test_severity, test_access_level, test_remediation, AccessLevel, Severity
from testsuitebase.testsuitebase import *
from pyinfoblox import InfobloxWAPI

import atexit
import ssl


@test_parameter('infoblox', 'Infoblox Appliance', 'infoblox_address', 'Infoblox Appliance Address', 'server', 'String', '')
@test_parameter('infoblox', 'Infoblox Appliance', 'infoblox_username', 'Infoblox Appliance Username', 'root', 'String', 'root')
@test_parameter('infoblox', 'Infoblox Appliance', 'infoblox_password', 'Infoblox Appliance Password', 'password', 'Password', '')
@test_suite('Infoblox Tests', 'A collection of Infoblox of tests', 'Infoblox', 8, 2, 1)
class InfobloxTestSuite(TestSuiteBase):

    @test_name("Check InfoBlox Connectivity")
    @test_description("Checks that the infoblox can be accessed.")
    @test_access_level(AccessLevel.NORMAL.value)
    @test_severity(Severity.NORMAL.value)
    @test_remediation("http://www.google.com")
    @test
    def check_vc_connectivity(self,
                              infoblox_address,
                              infoblox_username,
                              infoblox_password,
                         ):
        infoblox = InfobloxWAPI(
                    username=infoblox_username,
                    password=infoblox_password,
                    wapi='https://' + infoblox_address + '/wapi/v1.1/'
                    )
        networks = infoblox.network.get()

        assert networks  != None, "Failed to connect to Infoblox"

        return True


################################################################################################
#
# Test Execution
#
################################################################################################
def register(host, token, modulename, venv):
    """
    This method is called by the vRealize Health Service framework to register the test classes
    :param host: the host to register with
    :param token: the security token used to make the call
    :param modulename: the name of this module
    :param venv: name of the virtual environment that these tests will run it
    :return:
    """
    suite = InfobloxTestSuite()
    suite.register_tests_with_framework(host, token, modulename, venv)

